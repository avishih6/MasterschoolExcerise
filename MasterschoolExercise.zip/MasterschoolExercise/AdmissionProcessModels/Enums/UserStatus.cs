namespace AdmissionProcessModels.Enums;

public enum UserStatus
{
    InProgress = 0,
    Accepted = 1,
    Rejected = 2
}
