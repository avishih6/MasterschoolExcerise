namespace AdmissionProcessModels.DTOs;

public class CurrentProgressResponse
{
    public string? CurrentStep { get; set; }
    public string? CurrentTask { get; set; }
}
