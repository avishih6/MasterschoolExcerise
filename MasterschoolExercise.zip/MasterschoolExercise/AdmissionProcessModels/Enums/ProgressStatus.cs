namespace AdmissionProcessModels.Enums;

public enum ProgressStatus
{
    NotStarted = 0,
    Accepted = 1,
    Rejected = 2
}
