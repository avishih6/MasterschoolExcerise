namespace AdmissionProcessApi.DTOs;

public class CreateUserRequest
{
    public string Email { get; set; } = string.Empty;
}
