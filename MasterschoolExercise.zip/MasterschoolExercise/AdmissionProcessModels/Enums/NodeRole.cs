namespace AdmissionProcessModels.Enums;

public enum NodeRole
{
    Step = 1,
    Task = 2
}
