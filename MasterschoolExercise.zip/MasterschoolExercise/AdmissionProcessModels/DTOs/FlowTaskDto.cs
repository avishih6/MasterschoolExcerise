namespace AdmissionProcessModels.DTOs;

public class FlowTaskDto
{
    public string Name { get; set; } = string.Empty;
    public string StepName { get; set; } = string.Empty;
}
