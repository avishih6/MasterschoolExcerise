namespace AdmissionProcessDAL.Configuration.Models;

public class NodesConfiguration
{
    public List<NodeDefinition> Nodes { get; set; } = new();
}
