namespace AdmissionProcessDAL.Models;

public class DerivedFactMapping
{
    public string SourceField { get; set; } = string.Empty;
    public string TargetFactName { get; set; } = string.Empty;
}
